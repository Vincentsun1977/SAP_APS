#!/bin/bash
# 停止服务脚本

pkill -f "streamlit run streamlit_app/aps_dashboard.py"
echo "✓ Dashboard已停止"
