# SAP Production Plan Predictor

## 项目简介

基于 XGBoost 机器学习模型的 SAP 生产订单交付预测系统,用于预测生产订单是否能准时交付。

## 功能特性

- 📊 **数据导入**: 支持从 SAP 导出的 CSV 文件导入生产计划数据
- 🤖 **智能预测**: 使用 XGBoost 模型预测订单延期风险
- 📈 **特征工程**: 30+ 自动化特征生成（时间、历史、资源等）
- 🎯 **风险评估**: 实时延期概率计算和风险等级划分
- 📉 **可视化**: Streamlit 交互式仪表板
- 🔌 **API 服务**: FastAPI RESTful 接口
- ☁️ **云数据库**: Supabase 数据持久化

## 技术栈

- **语言**: Python 3.9+
- **ML框架**: XGBoost 2.0
- **数据处理**: Pandas, NumPy
- **数据库**: Supabase (PostgreSQL)
- **API**: FastAPI
- **可视化**: Streamlit, Plotly
- **部署**: Docker (可选)

## 快速开始

### 1. 环境准备

```bash
# 克隆项目
cd sap-production-predictor

# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate  # Windows: venv\\Scripts\\activate

# 安装依赖
pip install -r requirements.txt
```

### 2. 配置环境变量

```bash
# 复制环境变量模板
cp .env.example .env

# 编辑 .env 文件，填入你的 Supabase 凭证
nano .env
```

### 3. 初始化数据库

```bash
# 创建数据库表
python scripts/init_database.py
```

### 4. 准备数据

将 SAP 导出的 CSV 文件放入 `data/raw/` 目录:

```
data/raw/
├── production_orders.csv
├── material_master.csv
└── work_centers.csv
```

### 5. 训练模型

```bash
# 执行数据处理和模型训练
python scripts/train_model.py
```

### 6. 启动服务

```bash
# 启动 API 服务
python src/api/main.py

# 或启动 Streamlit 仪表板
streamlit run streamlit_app/app.py
```

## 项目结构

```
sap-production-predictor/
├── config/              # 配置文件
├── data/               # 数据目录
│   ├── raw/           # 原始CSV数据
│   ├── processed/     # 处理后数据
│   └── sample/        # 示例数据
├── src/               # 源代码
│   ├── data_collection/   # 数据采集
│   ├── data_processing/   # 数据处理
│   ├── models/           # 模型相关
│   ├── database/         # 数据库操作
│   ├── api/             # API服务
│   └── utils/           # 工具函数
├── notebooks/          # Jupyter Notebooks
├── models/            # 保存的模型
├── scripts/           # 脚本
├── streamlit_app/     # Streamlit应用
├── tests/             # 测试
└── docs/              # 文档
```

## 数据格式

### 生产订单 CSV 格式

```csv
order_id,material_id,plant,order_type,planned_start,planned_finish,actual_finish,planned_qty,status,priority
10000001,MAT001,1000,ZP01,2024-01-01,2024-01-15,2024-01-18,100,CNF,1
10000002,MAT002,1000,ZP01,2024-01-05,2024-01-20,2024-01-19,200,CNF,2
```

## API 使用

### 预测单个订单

```bash
curl -X POST "http://localhost:8000/predict" \\
  -H "Content-Type: application/json" \\
  -d '{
    "order_id": "10000123",
    "material_id": "MAT001",
    "plant": "1000",
    "planned_qty": 100,
    "planned_start": "2024-12-01",
    "planned_finish": "2024-12-15"
  }'
```

### 响应示例

```json
{
  "order_id": "10000123",
  "prediction": "延期",
  "delay_probability": 0.78,
  "risk_level": "高风险",
  "recommended_action": "建议提前安排资源"
}
```

## 模型性能

当前模型指标（基于测试集）:

- **准确率**: 82%
- **精确率**: 79%
- **召回率**: 85%
- **F1分数**: 0.82
- **AUC-ROC**: 0.88

## 开发指南

### 运行测试

```bash
pytest tests/
```

### 代码风格

```bash
# 格式化代码
black src/

# 类型检查
mypy src/
```

## 常见问题

### Q: 如何获取 Supabase 凭证？
A: 访问 [supabase.com](https://supabase.com)，创建项目后在 Settings > API 中获取。

### Q: 模型多久需要重新训练？
A: 建议每月或每季度重新训练一次，或当模型性能下降时。

### Q: 支持实时数据吗？
A: 当前版本基于 CSV 批量导入，v2.0 计划支持 SAP API 实时同步。

## 贡献

欢迎提交 Issue 和 Pull Request！

## 许可证

MIT License

## 联系方式

- 项目负责人: [Your Name]
- Email: [your.email@example.com]

---

**版本**: v1.0.0  
**最后更新**: 2025-12-22
