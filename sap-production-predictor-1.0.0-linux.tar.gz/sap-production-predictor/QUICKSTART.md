# 快速开始指南

## Linux服务器部署

### 1. 解压文件
```bash
tar -xzf sap-production-predictor-*.tar.gz
cd sap-production-predictor
```

### 2. 自动部署
```bash
chmod +x deploy.sh
./deploy.sh
```

### 3. 准备数据
将以下CSV文件放入 `data/raw/` 目录：
- Order.csv
- FG.csv
- Capacity.csv
- APS.csv
- History.csv（必需）

### 4. 训练模型
```bash
source venv/bin/activate
python scripts/train_aps_model.py
```

### 5. 启动Dashboard

**方式A：直接启动**
```bash
./start.sh
```

**方式B：使用systemd（推荐）**
```bash
# 安装服务
sudo cp config/sap-predictor.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable sap-predictor
sudo systemctl start sap-predictor

# 查看状态
sudo systemctl status sap-predictor

# 查看日志
sudo journalctl -u sap-predictor -f
```

### 6. 访问Dashboard
打开浏览器访问：
- http://<服务器IP>:8501

### 停止服务
```bash
# 方式A
./stop.sh

# 方式B（使用systemd）
sudo systemctl stop sap-predictor
```

## 防火墙配置

如果无法访问Dashboard，可能需要开放端口：

```bash
# Ubuntu/Debian
sudo ufw allow 8501

# CentOS/RHEL
sudo firewall-cmd --permanent --add-port=8501/tcp
sudo firewall-cmd --reload
```

## 故障排查

### 问题1: 端口已被占用
```bash
# 查看占用端口的进程
lsof -i :8501

# 更换端口启动
streamlit run streamlit_app/aps_dashboard.py --server.port 8502
```

### 问题2: 权限问题
```bash
# 给予执行权限
chmod +x deploy.sh start.sh stop.sh
```

### 问题3: 内存不足
编辑 `streamlit_app/aps_dashboard.py`，在文件开头添加：
```python
import os
os.environ['STREAMLIT_SERVER_MAX_UPLOAD_SIZE'] = '200'
```

更多帮助请参考 `DEPLOYMENT.md`
