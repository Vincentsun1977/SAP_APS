#!/bin/bash
# Linux服务器部署脚本

set -e

echo "================================================"
echo "  SAP生产延迟预测系统 - 自动部署"
echo "================================================"

# 检查Python版本
echo "🔍 检查Python版本..."
if ! command -v python3 &> /dev/null; then
    echo "❌ 错误: 未找到Python3，请先安装Python 3.9+"
    exit 1
fi

PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
echo "  ✓ Python版本: $PYTHON_VERSION"

# 创建虚拟环境
echo "🔧 创建虚拟环境..."
python3 -m venv venv
source venv/bin/activate

# 升级pip
echo "⬆️  升级pip..."
pip install --upgrade pip

# 安装依赖
echo "📦 安装Python依赖..."
pip install -r requirements.txt

# 创建.env文件（如果不存在）
if [ ! -f .env ]; then
    if [ -f .env.example ]; then
        cp .env.example .env
        echo "  ✓ 已创建.env配置文件，请编辑填入实际配置"
    fi
fi

# 检查数据文件
echo "📊 检查数据文件..."
if [ ! -f "data/raw/History.csv" ]; then
    echo "  ⚠️  警告: 未找到 data/raw/History.csv"
    echo "  请将CSV文件放入 data/raw/ 目录"
fi

# 检查模型文件
echo "🤖 检查模型文件..."
if ! ls models/*.json 1> /dev/null 2>&1; then
    echo "  ⚠️  警告: 未找到训练好的模型"
    echo "  请运行: python scripts/train_aps_model.py"
fi

echo ""
echo "================================================"
echo "✅ 部署完成！"
echo "================================================"
echo ""
echo "📝 下一步操作："
echo "  1. 将CSV数据文件放入: data/raw/"
echo "  2. 训练模型: python scripts/train_aps_model.py"
echo "  3. 启动Dashboard: streamlit run streamlit_app/aps_dashboard.py"
echo ""
echo "或使用systemd服务（推荐）："
echo "  sudo cp config/sap-predictor.service /etc/systemd/system/"
echo "  sudo systemctl daemon-reload"
echo "  sudo systemctl enable sap-predictor"
echo "  sudo systemctl start sap-predictor"
echo ""
