#!/bin/bash
# 快速启动脚本

source venv/bin/activate
streamlit run streamlit_app/aps_dashboard.py --server.port 8501 --server.address 0.0.0.0
